### Granja

### Descripción

1. Hay dos tipos de animales, Porcinos y Bovinos, ambos tienen una fecha de nacimiento, un peso y sexo.
2. Las razas de los porcinos son Duroc, Kunekune y Cerdo Hampshire, mientras que las de los bovinos son Angus, Hereford y Holstein.
3. Se necesita armar la dieta de los animales, para ello se debe tener en cuenta que los porcinos comen 2kg de alimento por cada kg de peso y los bovinos 1.5kg de alimento por cada kg de peso.
4. El alimento se compone de 50% de maíz, 30% de soja y 20% de trigo para los porcinos, 
5. El alimento se compone de 40% de maíz, 30% de soja y 30% de forraje para los bovinos.
