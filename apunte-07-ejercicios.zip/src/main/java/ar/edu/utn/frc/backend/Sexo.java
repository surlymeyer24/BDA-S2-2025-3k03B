package ar.edu.utn.frc.backend;

public enum Sexo {
	MACHO,
	HEMBRA;
}
