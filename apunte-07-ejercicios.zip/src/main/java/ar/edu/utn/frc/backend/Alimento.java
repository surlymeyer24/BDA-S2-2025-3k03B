package ar.edu.utn.frc.backend;

public enum Alimento {
	MAIZ,
	FORRAJE,
	TRIGO,
	SOJA,
	SORGO;
}
